const Anthropic = require('@anthropic-ai/sdk');

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// Known creator detection
const CREATORS = {
  'mrbeast': { name: 'MrBeast', niche: 'challenges/philanthropy' },
  'ishowspeed': { name: 'IShowSpeed', niche: 'reactions/gaming' },
  'kaicenat': { name: 'Kai Cenat', niche: 'streaming/entertainment' },
  'pewdiepie': { name: 'PewDiePie', niche: 'gaming/commentary' },
  'stevewilldoit': { name: 'SteveWillDoIt', niche: 'stunts/challenges' },
  'ninja': { name: 'Ninja', niche: 'gaming/fortnite' },
  'clavicular': { name: 'Clavicular', niche: 'comedy/skits' },
  'adinross': { name: 'Adin Ross', niche: 'streaming/reactions' },
  'neon': { name: 'Neon', niche: 'IRL/streaming' },
  'clix': { name: 'Clix', niche: 'gaming/fortnite' },
  'marlon': { name: 'Marlon', niche: 'comedy/reactions' },
};

function detectCreator(uploaderName, videoTitle) {
  const combined = `${uploaderName} ${videoTitle}`.toLowerCase().replace(/[^a-z]/g, '');
  for (const [key, info] of Object.entries(CREATORS)) {
    if (combined.includes(key)) return info;
  }
  return { name: uploaderName || 'Unknown Creator', niche: 'general' };
}

/**
 * Analyzes transcript with Claude to find viral clip moments
 * Returns array of clips with scores, headers, hooks, etc.
 */
async function analyzeTranscript(transcript, videoMeta) {
  console.log('🧠 Analyzing with Claude AI...');

  const creator = detectCreator(videoMeta.uploader, videoMeta.title);

  // Build transcript with timestamps for Claude
  const transcriptText = transcript.segments
    .map(s => `[${formatTime(s.start)} - ${formatTime(s.end)}] ${s.text}`)
    .join('\n');

  const prompt = `You are an expert viral content analyst. Your job is to find the most viral-worthy moments in this video transcript and generate professional short-form clip data.

VIDEO INFO:
- Title: ${videoMeta.title}
- Creator: ${creator.name} (${creator.niche})
- Duration: ${videoMeta.durationFormatted}
- Full duration: ${videoMeta.duration} seconds

TRANSCRIPT WITH TIMESTAMPS:
${transcriptText}

TASK: Find 8-15 viral-worthy clip moments. Each clip should be 15-60 seconds long.

Look for:
- Emotional peaks (shock, laughter, surprise, tension)
- Quotable moments / catchphrases
- Dramatic reveals or plot twists
- Arguments, debates, or confrontations
- Wholesome or heartwarming moments
- Funny reactions or fails
- Impressive achievements or stunts
- Controversial or polarizing statements

For EACH clip, provide:
1. Exact start and end timestamps (must be within the video duration)
2. A viral score 0-100 based on: emotional intensity, shareability, hook potential, visual interest
3. A scroll-stopping AI header (5-8 words, uses emotion/curiosity gap)
4. A 3-second hook line (the first thing viewers hear/read)
5. A clip title with emoji for social media
6. An SEO-optimized title under 65 characters
7. A 2-sentence description
8. Best platform (YouTube Shorts, TikTok, or Instagram Reels)
9. Predicted view range
10. 5 relevant hashtags
11. Why this specific moment will go viral (1-2 sentences)
12. The emotion category: shock, humor, hype, awe, tension, joy, anger, cringe
13. The content category: highlight, reaction, funny, dramatic, educational, debate

Respond ONLY with valid JSON. No markdown, no explanation, just the JSON object:
{
  "totalClipsFound": <number>,
  "avgViralScore": <number>,
  "clips": [
    {
      "id": 1,
      "startTime": "M:SS",
      "endTime": "M:SS",
      "startSeconds": <float>,
      "endSeconds": <float>,
      "duration": "0:SS",
      "durationSeconds": <float>,
      "viralScore": <0-100>,
      "engagementScore": <0-100>,
      "retentionScore": <0-100>,
      "shareabilityScore": <0-100>,
      "aiHeader": "<5-8 word header>",
      "hookLine": "<3s hook>",
      "clipTitle": "<title with emoji>",
      "seoTitle": "<SEO title under 65 chars>",
      "description": "<2 sentences>",
      "platform": "<YouTube Shorts|TikTok|Instagram Reels>",
      "predictedViews": "<range like 100K-500K>",
      "hashtags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"],
      "captionStyle": "Bold Word-by-Word",
      "whyViral": "<1-2 sentences>",
      "emotion": "<emotion category>",
      "category": "<content category>",
      "transcriptSegment": "<the actual words spoken in this clip>"
    }
  ]
}`;

  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 8000,
    messages: [{ role: 'user', content: prompt }],
  });

  // Extract text from response
  const responseText = response.content
    .filter(block => block.type === 'text')
    .map(block => block.text)
    .join('');

  // Parse JSON (handle potential markdown fencing)
  const cleaned = responseText.replace(/```json\s?|```/g, '').trim();
  const analysis = JSON.parse(cleaned);

  // Validate and fix timestamps
  analysis.clips = analysis.clips
    .filter(c => c.startSeconds >= 0 && c.endSeconds <= videoMeta.duration + 5)
    .map((c, i) => ({
      ...c,
      id: i + 1,
      startSeconds: Math.max(0, c.startSeconds),
      endSeconds: Math.min(c.endSeconds, videoMeta.duration),
      durationSeconds: c.endSeconds - c.startSeconds,
    }))
    .sort((a, b) => b.viralScore - a.viralScore);

  console.log(`✅ Found ${analysis.clips.length} viral moments`);

  return {
    ...analysis,
    creator,
    videoTitle: videoMeta.title,
    videoDuration: videoMeta.durationFormatted,
  };
}

function formatTime(seconds) {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
}

module.exports = { analyzeTranscript, detectCreator };
